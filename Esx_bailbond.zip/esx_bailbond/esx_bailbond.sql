USE `zap378899-1`;

INSERT INTO `addon_account` (name, label, shared) VALUES
	('society_bailbond', 'bailbond', 1)
;

INSERT INTO `datastore` (name, label, shared) VALUES
	('society_bailbond', 'bailbond', 1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES
	('society_bailbond', 'bailbond', 1)
;

INSERT INTO `jobs` (name, label) VALUES
	('bailbond','bailbond')
;

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
	('bailbond',1,'bailbond','bailbond',20,'{}','{}'),
	('bailbond',2,'Boss','Boss',40,'{}','{}'),
;

CREATE TABLE `fine_typesBB` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`label` varchar(255) DEFAULT NULL,
	`amount` int(11) DEFAULT NULL,
	`category` int(11) DEFAULT NULL,

	PRIMARY KEY (`id`)
);

INSERT INTO `fine_typesBB` (label, amount, category) VALUES
	('Usage abusif du klaxon',30,0),
	('Franchir une ligne continue',40,0),
;
